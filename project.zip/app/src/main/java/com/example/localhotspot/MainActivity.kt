package com.example.localhotspot

import android.Manifest
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var wifiManager: WifiManager
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var statusText: TextView
    private lateinit var ssidText: TextView
    private lateinit var passwordText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) startHotspot()
            else toast("Permission denied - cannot start hotspot")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager

        statusText = findViewById(R.id.statusText)
        ssidText = findViewById(R.id.ssidText)
        passwordText = findViewById(R.id.passwordText)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)

        startButton.setOnClickListener { ensurePermissionsThenStart() }
        stopButton.setOnClickListener { stopHotspot() }
        render(false, null, null)
    }

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun ensurePermissionsThenStart() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startHotspot() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startHotspot() {
        if (reservation != null) return
        try {
            wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation) {
                    reservation?.close()
                    reservation = res
                    val ssid: String?
                    val pass: String?
                    if (Build.VERSION.SDK_INT >= 30) {
                        val cfg = res.softApConfiguration
                        @Suppress("DEPRECATION")
                        ssid = cfg.ssid
                        pass = cfg.passphrase
                    } else {
                        @Suppress("DEPRECATION")
                        val cfg = res.wifiConfiguration
                        ssid = cfg?.SSID
                        pass = cfg?.preSharedKey
                    }
                    render(true, ssid, pass)
                }

                override fun onStopped() {
                    reservation = null
                    render(false, null, null)
                }

                override fun onFailed(reason: Int) {
                    reservation = null
                    render(false, null, null)
                    val msg = when (reason) {
                        ERROR_NO_CHANNEL -> "No channel available"
                        ERROR_TETHERING_DISALLOWED -> "Tethering disallowed on this device"
                        ERROR_INCOMPATIBLE_MODE -> "Incompatible mode (turn off Wi-Fi tethering/other hotspot)"
                        else -> "Unknown error ($reason)"
                    }
                    toast("Hotspot failed: $msg")
                }
            }, handler)
        } catch (e: SecurityException) {
            toast("Permission error: ${e.message}")
        } catch (e: IllegalStateException) {
            toast("Could not start: ${e.message}")
        }
    }

    private fun stopHotspot() {
        reservation?.close()
        reservation = null
        render(false, null, null)
    }

    private fun render(active: Boolean, ssid: String?, pass: String?) {
        statusText.text =
            if (active) "Hotspot ACTIVE (local only – no internet)" else "Hotspot OFF"
        ssidText.text = "SSID: ${ssid ?: "-"}"
        passwordText.text = "Password: ${pass ?: "-"}"
        startButton.isEnabled = !active
        stopButton.isEnabled = active
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        reservation?.close()
        reservation = null
        super.onDestroy()
    }
}
